<?php

namespace app\api\controller;

use think\Controller;
use think\Db;
use think\Request;

class Food extends Controller
{
   //获取导航菜系
    public function navigation(){
        $data = db('navigation')
            ->where('switch','<>',0)
            ->select();
        if($data){
            return json(["state"=>ApiConst::OBTAIN_NAV_SUCCESS,"msg"=>ApiConst::MSG_NAV_SUCCESS,"data"=>$data]);
        }else{
            return json(["state"=>ApiConst::OBTAIN_NAV_ERROR,"msg"=>ApiConst::MSG_NAV_ERROR]);
        }
    }

    //获取二级菜系表
    public function dishlist(){
        $data = db('dishlist')
            ->where('switch','<>',0)
            ->select();
        if($data){
            return json(["state"=>ApiConst::OBTATN_LIST_SUCCESS,"msg"=>ApiConst::MSG_LIST_SUCCESS,"data"=>$data]);
        }else{
            return json(["state"=>ApiConst::OBTATN_LIST_ERROR,"msg"=>ApiConst::MSG_LIST_ERROR]);
        }
    }

    //获取所有的美食信息
    public function food(){
        $data = db('food')
            ->alias('a')
            ->join('navigation b','a.nid=b.id')
            ->join('dishlist c','a.gid=c.id')
            ->join('flavor d','a.fid=d.id')
            ->where('a.switch','<>',0)
            ->field('a.id,a.name,a.price,a.picture,a.details,a.time,a.number,b.navclass,c.generic,d.category')
            ->select();
        if($data){
            return json(["state"=>ApiConst::OBTATN_FOOD_SUCCESS,"msg"=>ApiConst::MSG_FOOD_SUCCESS,"data"=>$data]);
        }else{
            return json(["state"=>ApiConst::OBTATN_FOOD_ERROR,"msg"=>ApiConst::MSG_FOOD_ERROR]);
        }
    }

    //获取搜索的美食
    public function search(){
        //获取前台提交的搜索名称
        $search = input('search');
        //echo $search;
        //将获取的数据中的双引号去掉
        $like=str_replace('"', '', $search);
        //echo $like;
        $data = db('food')
            ->where('name','like',"%$like%")
            ->where('switch','<>','0')
            ->field('or_food.id,or_food.name,or_food.price,or_food.picture,or_food.details,or_food.time,or_food.number')
            ->select();
        if($data){
            return json(["state"=>ApiConst::SEARCH_FOOD_SUCCESS,"msg"=>ApiConst::MSG_SEARCH_SUCCESS,"data"=>$data]);
        }else{
            return json(["state"=>ApiConst::SEARCH_FOOD_ERROR,"msg"=>ApiConst::MSG_SEARCH_ERROR]);
        }
    }

    //获取单击之后的美食详情
    public function details(){
        //获取要查看美食的id
        $id = input('id');
        $data = db('food')
            ->alias('a')
            ->join('navigation b','a.nid=b.id')
            ->join('dishlist c','a.gid=c.id')
            ->join('flavor d','a.fid=d.id')
            ->where('a.id',$id)
            ->field('a.id,a.name,b.navclass,c.generic,a.price,a.picture,a.details,d.category,a.time,a.number')
            ->select();
        if($data){
            return json(["state"=>ApiConst::DETAILS_FOOD_SUCCESS,"msg"=>ApiConst::MSG_DETAILS_SUCCESS,"data"=>$data]);
        }else{
            return json(["state"=>ApiConst::DETAILS_FOOD_ERROR,"msg"=>ApiConst::MSG_DETAILS_ERROR]);
        }
    }

    //单击左侧导航出现相应的美食
    public function screen(){
        $id = input('id');
//        $gid = input('gid');
        $data = db('food')
            ->alias('a')
            ->join('navigation b','a.nid=b.id')
            ->join('dishlist c','a.gid=c.id')
            ->join('flavor d','a.fid=d.id')
            ->where('a.nid',$id)
            ->where('a.switch','<>',0)
            ->field('a.id,a.name,b.navclass,c.generic,a.price,a.picture,a.details,d.category,a.time,a.number')
            ->select();
        if($data){
            return json(["state"=>ApiConst::SCREEN_FOOD_SUCCESS,"msg"=>ApiConst::MSG_SCREEN_SUCCESS,"data"=>$data]);
        }else{
            return json(["state"=>ApiConst::SCREEN_FOOD_ERROR,"msg"=>ApiConst::MSG_SCREEN_ERROR]);
        }
    }

    //推荐美食
    public function recommend(){
        $data = db("food")
            ->alias('a')
            ->join('navigation b','a.nid=b.id')
            ->join('dishlist c','a.gid=c.id')
            ->join('flavor d','a.fid=d.id')
            ->order('a.number desc')
            ->limit(15)
            ->where('a.switch','<>',0)
            ->field('a.id,a.name,b.navclass,c.generic,a.price,a.picture,a.details,d.category,a.time,a.number')
            ->select();
        if($data){
            return json(["state"=>ApiConst::RECOMMEND_FOOD_SUCCESS,"msg"=>ApiConst::MSG_RECOMMEND_SUCCESS,"data"=>$data]);
        }else{
            return json(["state"=>ApiConst::RECOMMEND_FOOD_ERROR,"msg"=>ApiConst::MSG_RECOMMEND_ERROR]);
        }
    }

}
