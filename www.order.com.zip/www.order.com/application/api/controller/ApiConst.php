<?php

namespace app\api\controller;

use think\Controller;
use think\Request;

class ApiConst extends Controller
{
    //包间首页左侧导航
    const OBTAIN_NAV_SUCCESS = 1001;  //获取包间首页左侧导航成功
    const OBTAIN_NAV_ERROR = 1002;  //获取包间首页左侧导航失败
    const MSG_NAV_SUCCESS = "获取成功";  //获取包间首页左侧导航失败 文字解释
    const MSG_NAV_ERROR = "获取失败";  //获取包间首页左侧导航失败  文字解释

    //包间首页二级菜系
    const OBTATN_LIST_SUCCESS = 1003; //获取包间首页二级导航菜系成功
    const OBTATN_LIST_ERROR = 1004; //获取包间首页二级导航菜系失败
    const MSG_LIST_SUCCESS = "获取成功"; //获取包间首页二级导航菜系成功  文字解释
    const MSG_LIST_ERROR = "获取失败"; //获取包间首页二级导航菜系失败  文字解释

    //获取美食的所有信息
    const OBTATN_FOOD_SUCCESS = 1005; //获取美食的所有信息成功
    const OBTATN_FOOD_ERROR = 1006; //获取美食的所有信息失败
    const MSG_FOOD_SUCCESS = "获取成功"; //获取美食的所有信息成功 文字解释
    const MSG_FOOD_ERROR = "获取失败"; //获取没事的所有信息失败 文字解释

    //获取搜索的美食的详情信息
    const SEARCH_FOOD_SUCCESS = 1007; //搜索的美食的详情信息成功
    const SEARCH_FOOD_ERROR = 1008; //搜索的美食的详情信息失败
    const MSG_SEARCH_SUCCESS = "搜索成功"; //搜索美食的详情信息成功 文字解释
    const MSG_SEARCH_ERROR = "搜索失败"; //搜索美食的详情信息失败 文字解释

    //利用美食id查询美食的详情
    const DETAILS_FOOD_SUCCESS = 1009; //获取美食详情成功
    const DETAILS_FOOD_ERROR = 1010; //获取美食详情失败
    const MSG_DETAILS_SUCCESS = "获取成功"; //获取美食详情成功 文字解释
    const MSG_DETAILS_ERROR = "获取失败"; //获取美食详情失败 文字解释

    //利用导航中的id获取美食
    const SCREEN_FOOD_SUCCESS = 1011; //获取美食成功
    const SCREEN_FOOD_ERROR = 1012; //获取美食失败
    const MSG_SCREEN_SUCCESS = "获取成功"; //获取美食成功 文字解释
    const MSG_SCREEN_ERROR = "获取失败"; //获取美食失败  文字解释

    //获取推荐美食
    const RECOMMEND_FOOD_SUCCESS = 1013; //获取推荐美食成功
    const RECOMMEND_FOOD_ERROR = 1014; //获取推荐美食失败
    const MSG_RECOMMEND_SUCCESS = "获取成功"; //获取推荐美食成功 文字解释
    const MSG_RECOMMEND_ERROR = "获取失败"; //获取推荐美食失败 文字解释

    //获取楼层信息
    const OBTATN_FLOOR_SUCCESS = 1015; //获取楼层信息成功
    const OBTATN_FLOOR_ERROR = 1016; //获取楼层信息失败
    const MSG_FLOOR_SUCCESS = "获取成功"; //获取楼层信息成功 文字解释
    const MSG_FLOOR_ERROR = "获取失败"; //获取楼层信息失败 文字解释

    //获取所有包间信息
    const OBTATN_ROOM_SUCCESS = 1017; //获取所有包间信息成功
    const OBTATN_ROOM_ERROR = 1018; //获取所有包间信息失败
    const MSG_ROOM_SUCCESS = "获取成功"; //获取所有包间信息成功 文字解释
    const MSG_ROOM_ERROR = "获取失败"; //获取所有包间信息失败 文字解释

    //单击右侧楼层信息筛选包间
    const SCREEN_ROOM_SUCCESS = 1019; //单击右侧楼层获取包间信息成功
    const SCREEN_ROOM_ERROR = 1020; //单击右侧楼层获取包间信息失败
    const MSG_SCREEN_ROOM_SUCCESS = "获取成功"; //单击右侧楼层获取包间成功 文字解释
    const MSG_SCREEN_ROOM_ERROR = "获取失败"; //单击右侧楼层获取包间失败 文字解释
}
