<?php

namespace app\api\controller;

use think\Controller;
use think\Request;

class Message extends Controller
{
    /**
     * 短信验证码
     *
     * @return \think\Response
     */
    public function verification()
    {
        //获取提交的手机号码
        $phone = input("post.phone");
        //随机数
        $code = mt_rand(1000,9999);
        //echo $code;
        //短信发送的sdk
        $host = "http://dingxin.market.alicloudapi.com";
        $path = "/dx/sendSms";
        $method = "POST";
        $appcode = "036b5d2a0be541ff82b3863fea3ff3c5";
        $headers = array();
        array_push($headers, "Authorization:APPCODE " . $appcode);
        $querys = "mobile={$phone}&param=code%3A{$code}&tpl_id=TP1711063";
        $bodys = "";
        $url = $host . $path . "?" . $querys;

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($curl, CURLOPT_FAILONERROR, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HEADER, true);
        if (1 == strpos("$" . $host, "https://")) {
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);

        }
        if (curl_exec($curl)){
            return json(["state"=>1000,"msg"=>"发送成功","data"=>$code]);
        }else{
            return json(["state"=>1001,"msg"=>"发送失败"]);
        }
    }

}
