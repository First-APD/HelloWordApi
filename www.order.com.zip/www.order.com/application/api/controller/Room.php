<?php

namespace app\api\controller;

use think\Controller;
use think\Request;

class Room extends Controller
{
    //获取所有楼层信息
    public function floor(){
        $data = db("address")
            ->where("switch","<>",0)
            ->select();
        if($data){
            return json(["state"=>ApiConst::OBTATN_FLOOR_SUCCESS,"msg"=>ApiConst::MSG_FLOOR_SUCCESS,"data"=>$data]);
        }else{
            return json(["state"=>ApiConst::OBTATN_FLOOR_ERROR,"msg"=>ApiConst::MSG_FLOOR_ERROR]);
        }
    }

    //获取所有包间信息
    public function room(){
        $data = db("room")
            ->where("switch","<>",0)
            ->field("id,aid,number,people,state")
            ->select();
        if($data){
            return json(["state"=>ApiConst::OBTATN_ROOM_SUCCESS,"msg"=>ApiConst::MSG_ROOM_SUCCESS,"data"=>$data]);
        }else{
            return json(["state"=>ApiConst::OBTATN_ROOM_ERROR,"msg"=>ApiConst::MSG_ROOM_ERROR]);
        }
    }

    //单击右侧楼层信息筛选包间
    public function screen(){
        //获取前台id
        $id = input('id');
        $data = db("room")
            ->where("aid",$id)
            ->field("id,aid,number,people,state")
            ->select();
        if($data){
            return json(["state"=>ApiConst::SCREEN_ROOM_SUCCESS,"msg"=>ApiConst::MSG_SCREEN_ROOM_SUCCESS,"data"=>$data]);
        }else{
            return json(["state"=>ApiConst::SCREEN_ROOM_ERROR,"msg"=>ApiConst::MSG_SCREEN_ROOM_ERROR]);
        }
    }
}
