/*
Navicat MySQL Data Transfer

Source Server         : root
Source Server Version : 50553
Source Host           : localhost:3306
Source Database       : order

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2019-11-05 14:36:49
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for or_address
-- ----------------------------
DROP TABLE IF EXISTS `or_address`;
CREATE TABLE `or_address` (
  `Id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `floor` varchar(255) NOT NULL DEFAULT '' COMMENT '楼层地址',
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='楼层表';

-- ----------------------------
-- Records of or_address
-- ----------------------------
INSERT INTO `or_address` VALUES ('1', '一楼');
INSERT INTO `or_address` VALUES ('2', '二楼');
INSERT INTO `or_address` VALUES ('3', '三楼');
INSERT INTO `or_address` VALUES ('4', '四楼');
INSERT INTO `or_address` VALUES ('5', '五楼');
INSERT INTO `or_address` VALUES ('6', '六楼');
INSERT INTO `or_address` VALUES ('7', '七楼');
INSERT INTO `or_address` VALUES ('8', '八楼');

-- ----------------------------
-- Table structure for or_admin
-- ----------------------------
DROP TABLE IF EXISTS `or_admin`;
CREATE TABLE `or_admin` (
  `Id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `username` varchar(255) NOT NULL DEFAULT '' COMMENT '用户名',
  `password` char(255) NOT NULL DEFAULT '' COMMENT '用户密码（md5加密）',
  `Jurisdiction` varchar(255) NOT NULL DEFAULT '' COMMENT '权限',
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='后台登录表';

-- ----------------------------
-- Records of or_admin
-- ----------------------------
INSERT INTO `or_admin` VALUES ('1', 'admin', 'admin', '0');

-- ----------------------------
-- Table structure for or_dishlist
-- ----------------------------
DROP TABLE IF EXISTS `or_dishlist`;
CREATE TABLE `or_dishlist` (
  `Id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `generic` varchar(255) NOT NULL DEFAULT '' COMMENT '菜品类型',
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='菜类表';

-- ----------------------------
-- Records of or_dishlist
-- ----------------------------
INSERT INTO `or_dishlist` VALUES ('1', '川菜');
INSERT INTO `or_dishlist` VALUES ('2', '粤菜');
INSERT INTO `or_dishlist` VALUES ('3', '浙菜');
INSERT INTO `or_dishlist` VALUES ('4', '鲁菜');
INSERT INTO `or_dishlist` VALUES ('5', '晋菜');
INSERT INTO `or_dishlist` VALUES ('6', '冀菜');
INSERT INTO `or_dishlist` VALUES ('7', '湘菜');
INSERT INTO `or_dishlist` VALUES ('8', '汤类');
INSERT INTO `or_dishlist` VALUES ('9', '其他');

-- ----------------------------
-- Table structure for or_flavor
-- ----------------------------
DROP TABLE IF EXISTS `or_flavor`;
CREATE TABLE `or_flavor` (
  `Id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `category` varchar(255) NOT NULL DEFAULT '' COMMENT '口味类别',
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='口味表';

-- ----------------------------
-- Records of or_flavor
-- ----------------------------
INSERT INTO `or_flavor` VALUES ('1', '酸');
INSERT INTO `or_flavor` VALUES ('2', '甜');
INSERT INTO `or_flavor` VALUES ('3', '苦');
INSERT INTO `or_flavor` VALUES ('4', '辣');
INSERT INTO `or_flavor` VALUES ('5', '微辣');
INSERT INTO `or_flavor` VALUES ('6', '微甜');
INSERT INTO `or_flavor` VALUES ('7', '微酸');
INSERT INTO `or_flavor` VALUES ('8', '微苦');
INSERT INTO `or_flavor` VALUES ('9', '大众');

-- ----------------------------
-- Table structure for or_food
-- ----------------------------
DROP TABLE IF EXISTS `or_food`;
CREATE TABLE `or_food` (
  `Id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '美食名称',
  `nid` varchar(255) NOT NULL DEFAULT '' COMMENT '导航表中的id（菜的类型）',
  ` gid` varchar(255) DEFAULT NULL COMMENT '菜类表中的id（菜的省份）',
  `price` varchar(255) NOT NULL DEFAULT '' COMMENT '价格',
  `picture` varchar(255) NOT NULL DEFAULT '' COMMENT '图片',
  `details` char(255) NOT NULL DEFAULT '' COMMENT '详情介绍',
  `fid` varchar(255) NOT NULL DEFAULT '大众' COMMENT '口味表中的id（美食的口味）',
  `time` varchar(255) NOT NULL DEFAULT '' COMMENT '预计时间',
  `number` varchar(255) NOT NULL DEFAULT '' COMMENT '下单量',
  `state` int(11) NOT NULL DEFAULT '1' COMMENT '显示状态（1正常显示  0隐藏显示）',
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='美食表';

-- ----------------------------
-- Records of or_food
-- ----------------------------
INSERT INTO `or_food` VALUES ('1', '特色烤全羊', '1', '9', '188', '', '', '大众', '', '', '1');
INSERT INTO `or_food` VALUES ('2', '纽西兰牛肋排', '2', '9', '588', '', '', '大众', '', '', '1');
INSERT INTO `or_food` VALUES ('3', '葱淋蛇碌', '1', '9', '99', '', '', '大众', '', '', '1');
INSERT INTO `or_food` VALUES ('4', '鲍汁海螺', '1', '9', '166', '', '', '大众', '', '', '1');
INSERT INTO `or_food` VALUES ('5', '剁椒炒鱼翅', '4', '9', '188', '', '', '大众', '', '', '1');
INSERT INTO `or_food` VALUES ('6', '处女冰激凌', '6', '9', '66', '', '', '大众', '', '', '1');
INSERT INTO `or_food` VALUES ('7', '风味干煸牛蛙', '1', '9', '120', '', '', '大众', '', '', '1');
INSERT INTO `or_food` VALUES ('8', '雪花牛肉粒拼醒目凉瓜', '3', '9', '66', '', '', '大众', '', '', '1');
INSERT INTO `or_food` VALUES ('9', '咸蛋皇蒸肉饼', '7', '9', '88', '', '', '大众', '', '', '1');
INSERT INTO `or_food` VALUES ('10', '雪花勇闯天涯', '5', '9', '66', '', '', '大众', '', '', '1');
INSERT INTO `or_food` VALUES ('11', '波尔多干红葡萄酒', '5', '9', '699', '', '', '大众', '', '', '1');
INSERT INTO `or_food` VALUES ('12', '茅台', '5', '9', '889', '', '', '大众', '', '', '1');
INSERT INTO `or_food` VALUES ('13', '泰式酸辣海鲜汤', '1', '8', '122', '', '', '大众', '', '', '1');
INSERT INTO `or_food` VALUES ('14', '鸭血毛肚血旺', '2', '1', '160', '', '', '大众', '', '', '1');
INSERT INTO `or_food` VALUES ('15', '宫保鸡丁', '4', '1', '130', '', '', '大众', '', '', '1');
INSERT INTO `or_food` VALUES ('16', '粤式龙虾', '2', '2', '168', '', '', '大众', '', '', '1');
INSERT INTO `or_food` VALUES ('17', '豉汁蒸凤爪', '2', '2', '228', '', '', '大众', '', '', '1');
INSERT INTO `or_food` VALUES ('18', '油爆大虾', '2', '3', '266', '', '', '大众', '', '', '1');
INSERT INTO `or_food` VALUES ('19', '蟹肉西兰花', '2', '3', '135', '', '', '大众', '', '', '1');
INSERT INTO `or_food` VALUES ('20', '九转大肠', '2', '4', '129', '', '', '大众', '', '', '1');
INSERT INTO `or_food` VALUES ('21', '葱烧海参', '2', '4', '220', '', '', '大众', '', '', '1');
INSERT INTO `or_food` VALUES ('22', '山西发糕', '', '5', '188', '', '', '大众', '', '', '1');
INSERT INTO `or_food` VALUES ('23', '山西过油肉', '', '5', '190', '', '', '大众', '', '', '1');
INSERT INTO `or_food` VALUES ('24', '锅包肘子', '', '6', '210', '', '', '大众', '', '', '1');
INSERT INTO `or_food` VALUES ('25', '桂花鱼翅', '', '6', '170', '', '', '大众', '', '', '1');
INSERT INTO `or_food` VALUES ('26', '剁椒鱼头', '1', '7', '160', '', '', '大众', '', '', '1');
INSERT INTO `or_food` VALUES ('27', '辣椒炒肉', '', '7', '120', '', '', '大众', '', '', '1');
INSERT INTO `or_food` VALUES ('28', '锦葵大虾汤', '1', '8', '188', '', '', '大众', '', '', '1');
INSERT INTO `or_food` VALUES ('29', '豆腐裙带菜大酱汤', '', '8', '135', '', '', '大众', '', '', '1');

-- ----------------------------
-- Table structure for or_member
-- ----------------------------
DROP TABLE IF EXISTS `or_member`;
CREATE TABLE `or_member` (
  `Id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '会员账号（随机账号）',
  `password` char(255) NOT NULL DEFAULT '' COMMENT '会员密码（md5加密）',
  `phone` varchar(255) NOT NULL DEFAULT '' COMMENT '会员等级(八折，九折)',
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员表';

-- ----------------------------
-- Records of or_member
-- ----------------------------

-- ----------------------------
-- Table structure for or_menu
-- ----------------------------
DROP TABLE IF EXISTS `or_menu`;
CREATE TABLE `or_menu` (
  `Id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `rid` varchar(255) NOT NULL DEFAULT '' COMMENT '房间号',
  `fid` varchar(255) NOT NULL DEFAULT '' COMMENT '美食表中的id',
  `number` varchar(255) NOT NULL DEFAULT '1' COMMENT '订单数量',
  `remarks` char(1) DEFAULT NULL COMMENT '备注',
  `state` int(11) NOT NULL DEFAULT '0' COMMENT '订单状态(0为删除订单,1为已在订单中)',
  `upper` int(11) NOT NULL COMMENT '上菜状态（0为等待中 1为已上菜）',
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='订单表';

-- ----------------------------
-- Records of or_menu
-- ----------------------------

-- ----------------------------
-- Table structure for or_navigation
-- ----------------------------
DROP TABLE IF EXISTS `or_navigation`;
CREATE TABLE `or_navigation` (
  `Id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `navclass` varchar(255) NOT NULL DEFAULT '' COMMENT '导航分类名称',
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='导航表';

-- ----------------------------
-- Records of or_navigation
-- ----------------------------
INSERT INTO `or_navigation` VALUES ('1', '今日推荐');
INSERT INTO `or_navigation` VALUES ('2', '招牌菜');
INSERT INTO `or_navigation` VALUES ('3', '凉菜');
INSERT INTO `or_navigation` VALUES ('4', '热菜');
INSERT INTO `or_navigation` VALUES ('5', '酒水');
INSERT INTO `or_navigation` VALUES ('6', '甜点');
INSERT INTO `or_navigation` VALUES ('7', '主食');

-- ----------------------------
-- Table structure for or_proposal
-- ----------------------------
DROP TABLE IF EXISTS `or_proposal`;
CREATE TABLE `or_proposal` (
  `Id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `rid` varchar(255) NOT NULL DEFAULT '' COMMENT '房间号',
  `grade` varchar(255) NOT NULL DEFAULT '' COMMENT '评价等级',
  `content` char(255) NOT NULL DEFAULT '' COMMENT '评价内容',
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='建议表';

-- ----------------------------
-- Records of or_proposal
-- ----------------------------

-- ----------------------------
-- Table structure for or_room
-- ----------------------------
DROP TABLE IF EXISTS `or_room`;
CREATE TABLE `or_room` (
  `Id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增',
  `aid` varchar(11) NOT NULL DEFAULT '' COMMENT '所属楼层',
  `number` varchar(255) NOT NULL DEFAULT '' COMMENT '房间号',
  `account` varchar(255) NOT NULL DEFAULT '' COMMENT '房间账号',
  `people` varchar(255) NOT NULL DEFAULT '' COMMENT '房间人数',
  `state` int(11) NOT NULL DEFAULT '0' COMMENT '房间状态（0为等待中，1为营业中）',
  `password` char(255) NOT NULL DEFAULT '' COMMENT '房间密码（MD5123456）',
  `mid` varchar(255) NOT NULL COMMENT '会员表中的id',
  `price` decimal(10,2) NOT NULL COMMENT '消费总价',
  `discount` decimal(10,2) NOT NULL COMMENT '打折后的总价',
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='房间表';

-- ----------------------------
-- Records of or_room
-- ----------------------------
INSERT INTO `or_room` VALUES ('1', '1', '101', '0371101', '15', '0', 'e10adc3949ba59abbe56e057f20f883e', '', '0.00', '0.00');
INSERT INTO `or_room` VALUES ('2', '1', '102', '0371102', '15', '0', 'e10adc3949ba59abbe56e057f20f883e', '', '0.00', '0.00');
INSERT INTO `or_room` VALUES ('3', '1', '103', '0371103', '15', '0', 'e10adc3949ba59abbe56e057f20f883e', '', '0.00', '0.00');
INSERT INTO `or_room` VALUES ('4', '2', '201', '0371201', '15', '0', 'e10adc3949ba59abbe56e057f20f883e', '', '0.00', '0.00');
INSERT INTO `or_room` VALUES ('5', '2', '202', '0371202', '15', '0', 'e10adc3949ba59abbe56e057f20f883e', '', '0.00', '0.00');
INSERT INTO `or_room` VALUES ('6', '2', '203', '0371203', '15', '0', 'e10adc3949ba59abbe56e057f20f883e', '', '0.00', '0.00');
INSERT INTO `or_room` VALUES ('7', '3', '301', '0371301', '15', '0', 'e10adc3949ba59abbe56e057f20f883e', '', '0.00', '0.00');
INSERT INTO `or_room` VALUES ('8', '3', '302', '0371302', '15', '0', 'e10adc3949ba59abbe56e057f20f883e', '', '0.00', '0.00');
INSERT INTO `or_room` VALUES ('9', '3', '303', '0371303', '15', '0', 'e10adc3949ba59abbe56e057f20f883e', '', '0.00', '0.00');
INSERT INTO `or_room` VALUES ('10', '4', '401', '0371401', '15', '0', 'e10adc3949ba59abbe56e057f20f883e', '', '0.00', '0.00');
INSERT INTO `or_room` VALUES ('11', '4', '402', '0371402', '30', '0', 'e10adc3949ba59abbe56e057f20f883e', '', '0.00', '0.00');
INSERT INTO `or_room` VALUES ('12', '4', '403', '0371403', '30', '0', 'e10adc3949ba59abbe56e057f20f883e', '', '0.00', '0.00');

-- ----------------------------
-- Table structure for or_rotation
-- ----------------------------
DROP TABLE IF EXISTS `or_rotation`;
CREATE TABLE `or_rotation` (
  `Id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `picture` varchar(255) NOT NULL DEFAULT '' COMMENT '图片',
  `fid` varchar(255) NOT NULL DEFAULT '' COMMENT '美食表中的id',
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='轮播图表';

-- ----------------------------
-- Records of or_rotation
-- ----------------------------

-- ----------------------------
-- Table structure for or_total
-- ----------------------------
DROP TABLE IF EXISTS `or_total`;
CREATE TABLE `or_total` (
  `Id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `rid` varchar(255) NOT NULL DEFAULT '' COMMENT '房间号',
  `mid` varchar(255) NOT NULL DEFAULT '' COMMENT '会员表中的id',
  `price` varchar(255) NOT NULL DEFAULT '' COMMENT '消费总价',
  `discount` varchar(255) NOT NULL DEFAULT '' COMMENT '打折之后的总价',
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='总价表';

-- ----------------------------
-- Records of or_total
-- ----------------------------
